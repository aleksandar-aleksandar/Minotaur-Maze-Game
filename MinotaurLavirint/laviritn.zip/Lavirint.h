#pragma once
#include <vector>
#include <unordered_map>
#include <string>

using namespace std;

class Lavirint {
public:
    int dim1, dim2;
    int brojPredmeta;
    vector<vector<char>> matrica;
    unordered_map<string, int> predmeti;

    int robotX, robotY;
    int minotaurX, minotaurY;
    int izlazX, izlazY;

    Lavirint(int d1, int d2, int p);
    void ispisiAsciiPoraz();
    void ispisiAsciiPobeda();
    void generisiLavirint();
    void ispisiLavirint();
    bool prohodan();
    bool proveriPobedu();
    bool proveriPoraz();
    void aktivirajPredmet();
    void izbrojElemente();
    bool pomeriRobota(int xPomeraj, int yPomeraj);
    bool pomeriMinotaura();

private:
    void dfs(int x, int y, vector<vector<bool>>& poseceno);
    void generisiPrimovAlgoritam();
};
