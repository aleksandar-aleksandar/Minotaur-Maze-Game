﻿#include "Lavirint.h"
#include <iostream>
#include <vector>
#include <queue>
#include <cstdlib>
#include <ctime>
#include <unordered_map>

using namespace std;

Lavirint::Lavirint(int d1, int d2, int p)
    : dim1(d1), dim2(d2), brojPredmeta(p), matrica(d1, vector<char>(d2, '#')) {
    
    predmeti["Magla rata"] = 0;
    predmeti["Mac"] = 0;
    predmeti["Stit"] = 0;
    predmeti["Cekic"] = 0;

}

void Lavirint::ispisiAsciiPoraz() {
    cout << "\033[31m"; // Crvena boja
    cout << R"(
██████╗░░█████╗░██████╗░░█████╗░███████╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗╚════██║
██████╔╝██║░░██║██████╔╝███████║░░███╔═╝
██╔═══╝░██║░░██║██╔══██╗██╔══██║██╔══╝░░
██║░░░░░╚█████╔╝██║░░██║██║░░██║███████╗
╚═╝░░░░░░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝
    )" << "\033[0m" << endl; // Reset boje
}

void Lavirint::ispisiAsciiPoraz() {
    cout << "\033[31m"; // Crvena boja
    cout << R"(
██████╗░░█████╗░██████╗░███████╗██████╗░░█████╗░
██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗
██████╔╝██║░░██║██████╦╝█████╗░░██║░░██║███████║
██╔═══╝░██║░░██║██╔══██╗██╔══╝░░██║░░██║██╔══██║
██║░░░░░╚█████╔╝██████╦╝███████╗██████╔╝██║░░██║
╚═╝░░░░░░╚════╝░╚═════╝░╚══════╝╚═════╝░╚═╝░░╚═╝
    )" << "\033[0m" << endl; // Reset boje
}

void Lavirint::generisiPrimovAlgoritam() {
    srand(time(0));
    vector<pair<int, int>> granice;

    int startX = 1 + rand() % (dim1 - 2);
    int startY = 1 + rand() % (dim2 - 2);
    matrica[startX][startY] = '.';

    granice.push_back({ startX - 1, startY });
    granice.push_back({ startX + 1, startY });
    granice.push_back({ startX, startY - 1 });
    granice.push_back({ startX, startY + 1 });

    while (!granice.empty()) {
        int index = rand() % granice.size();
        int x = granice[index].first;
        int y = granice[index].second;
        granice.erase(granice.begin() + index);

        if (x <= 0 || x >= dim1 - 1 || y <= 0 || y >= dim2 - 1 || matrica[x][y] == '.') continue;

        int count = 0;
        if (matrica[x - 1][y] == '.') count++;
        if (matrica[x + 1][y] == '.') count++;
        if (matrica[x][y - 1] == '.') count++;
        if (matrica[x][y + 1] == '.') count++;

        if (count == 1) { 
            matrica[x][y] = '.'; 
            granice.push_back({ x - 1, y });
            granice.push_back({ x + 1, y });
            granice.push_back({ x, y - 1 });
            granice.push_back({ x, y + 1 });
        }
    }
}

void Lavirint::generisiLavirint() {
    generisiPrimovAlgoritam();

    int ulazKolona = rand() % (dim2 - 2) + 1;
    int izlazKolona = rand() % (dim2 - 2) + 1;

    matrica[0][ulazKolona] = 'U';
    matrica[dim1 - 1][izlazKolona] = 'I';
    matrica[1][ulazKolona] = 'R';
    matrica[dim1 - 2][izlazKolona] = 'M';

    robotX = 1;
    robotY = ulazKolona;

    minotaurX = dim1 - 2;
    minotaurY = izlazKolona;

    izlazX = dim1 - 1;
    izlazY = izlazKolona;

    int unutrasnjaPolja = (dim1 - 1) * (dim2 - 1);
    int minZidovi = 2 * (dim1 + dim2); 
    int maksPredmeti = unutrasnjaPolja - minZidovi - 4;

    if (brojPredmeta > maksPredmeti) {
        cout << "Previše predmeta! Maksimalan broj predmeta za dimenzije " << dim1 << "x" << dim2
            << " je " << maksPredmeti << ". Automatski smanjujemo broj predmeta.\n";
        brojPredmeta = maksPredmeti;
    }

    for (int i = 0; i < brojPredmeta; i++) {
        int x, y;
        do {
            x = rand() % (dim1 - 2) + 1;
            y = rand() % (dim2 - 2) + 1;
        } while (matrica[x][y] != '.');

        matrica[x][y] = 'P';
    }
}

void Lavirint::dfs(int x, int y, vector<vector<bool>>& poseceno) {
    if (x < 0 || x >= dim1 || y < 0 || y >= dim2 || matrica[x][y] == '#' || poseceno[x][y]) {
        return;
    }

    poseceno[x][y] = true;

    dfs(x + 1, y, poseceno);
    dfs(x - 1, y, poseceno);
    dfs(x, y + 1, poseceno);
    dfs(x, y - 1, poseceno);
}

bool Lavirint::prohodan() {
    vector<vector<bool>> poseceno(dim1, vector<bool>(dim2, false));
    int ulazY = -1;

    for (int j = 0; j < dim2; j++) {
        if (matrica[0][j] == 'U') {
            ulazY = j;
            break;
        }
    }

    if (ulazY == -1) return false;

    dfs(0, ulazY, poseceno);

    for (int j = 0; j < dim2; j++) {
        if (matrica[dim1 - 1][j] == 'I' && poseceno[dim1 - 1][j]) {
            return true;
        }
    }
    return false;
}

bool Lavirint::proveriPobedu() {
    return (izlazX == robotX) && (izlazY && robotY);
}

bool Lavirint::proveriPoraz() {
    if (robotX == minotaurX && robotY == minotaurY) {
        if (predmeti["Mac"] > 0) {
            cout << "Robot je unistio Minotaura pomocu maca!\n";
            matrica[minotaurX][minotaurY] = '.';
            minotaurX = -1;
            minotaurY = -1;
            predmeti["Mac"] = 0;
            return false;
        }

        if (predmeti["Stit"] > 0) {
            cout << "Robot je preživeo napad Minotaura pomoću štita!\n";
            predmeti["Stit"] = 0;
            return false;
        }
        return true;
    }

    return false;
}

void Lavirint::ispisiLavirint() {
    if (predmeti["Magla rata"] > 0) {
        int startX = max(0, robotX - 1);
        int endX = min(dim1 - 1, robotX + 1);
        int startY = max(0, robotY - 1);
        int endY = min(dim2 - 1, robotY + 1);

        for (int i = 0; i < dim1; i++) {
            for (int j = 0; j < dim2; j++) {
                if (i >= startX && i <= endX && j >= startY && j <= endY) {
                    cout << matrica[i][j];
                }
                else {
                    cout << '?';
                }
            }
            cout << endl;
        }
    }
    else {
        for (const auto& red : matrica) {
            for (char polje : red) {
                cout << polje;
            }
            cout << endl;
        }
    }
}

void Lavirint::izbrojElemente() {
    unordered_map<char, int> brojac;
    brojac['#'] = 0;
    brojac['.'] = 0;
    brojac['U'] = 0;
    brojac['R'] = 0;
    brojac['I'] = 0;
    brojac['M'] = 0;
    brojac['P'] = 0;

    for (const auto& red : matrica) {
        for (char polje : red) {
            brojac[polje]++;
        }
    }

    cout << "\n------Statistika lavirinta-------" << endl;
    cout << "Visina: " << dim1 << endl;
    cout << "Sirina: " << dim2 << endl;
    cout << "Zidovi (#): " << brojac['#'] << endl;
    cout << "Zidovi (#) min: " << 2*(dim1+dim2) << endl;
    cout << "Prolazi (.): " << brojac['.'] << endl;
    cout << "Ulaz (U): " << brojac['U'] << endl;
    cout << "Robot (R): " << brojac['R'] << endl;
    cout << "Izlaz (I): " << brojac['I'] << endl;
    cout << "Minotaur (M): " << brojac['M'] << endl;
    cout << "Predmeti (P): " << brojac['P'] << endl;
    cout << "---------------------------------" << endl;

}

bool Lavirint::pomeriRobota(int xPomeraj, int yPomeraj) {
    int noviX = robotX + xPomeraj;
    int noviY = robotY + yPomeraj;

    if (noviX < 0 || noviX >= dim1 || noviY < 0 || noviY >= dim2) {
        cout << "Nemoguce se pomeriti: izlazite iz granica lavirinta.\n";
        return false;
    }

    if (matrica[noviX][noviY] == '#' && predmeti["Cekic"] == 0) {
        cout << "Nemoguce se pomeriti: zid na tom mestu.\n";
        return false;
    }

    this->pomeriMinotaura();

    if (matrica[noviX][noviY] == 'M' && predmeti["Stit"] == 0) {
        if (this->proveriPoraz()) {
            matrica[robotX][robotY] = 'M';
            cout << "Pojeo nas je Minotaur";
            return false;
        }
    }

    for (auto& predmet : predmeti) {
        if (predmet.second != 0) {
            predmet.second = predmet.second - 1;
        }
    }

    if (matrica[noviX][noviY] == 'P') {
        this->aktivirajPredmet();
    }

    for (auto predmet : predmeti) {
        cout << "Predmet " << predmet.first << " je ostalo " << predmet.second;
    }

    if (matrica[noviX][noviY] == '#') {
        predmeti["Cekic"] = 0;
    }

    matrica[robotX][robotY] = '.';
    robotX = noviX;
    robotY = noviY;
    matrica[robotX][robotY] = 'R';

    return false;
}

bool Lavirint::pomeriMinotaura() {
    vector<pair<int, int>> moguciPotezi = {
        {minotaurX - 1, minotaurY}, // Gore
        {minotaurX + 1, minotaurY}, // Dole
        {minotaurX, minotaurY - 1}, // Levo
        {minotaurX, minotaurY + 1}  // Desno
    };

    pair<int, int> prethodnaPozicija = { minotaurX, minotaurY };

    for (const auto& potez : moguciPotezi) {
        int noviX = potez.first;
        int noviY = potez.second;

        if (noviX >= 0 && noviX < dim1 && noviY >= 0 && noviY < dim2 && matrica[noviX][noviY] == 'R') {
            cout << "Minotaur je pojeo robota! Kraj igre.\n";
            return true; // Igra završava
        }
    }

    sort(moguciPotezi.begin(), moguciPotezi.end(), [this](const pair<int, int>& a, const pair<int, int>& b) {
        int distA = abs(a.first - robotX) + abs(a.second - robotY);
        int distB = abs(b.first - robotX) + abs(b.second - robotY);
        return distA < distB; 
        });

    for (const auto& potez : moguciPotezi) {
        int noviX = potez.first;
        int noviY = potez.second;

        if (noviX >= 0 && noviX < dim1 && noviY >= 0 && noviY < dim2 &&
            matrica[noviX][noviY] != '#' && make_pair(noviX, noviY) != prethodnaPozicija) {

            matrica[minotaurX][minotaurY] = '.';
            minotaurX = noviX;
            minotaurY = noviY;
            matrica[minotaurX][minotaurY] = 'M';
            return false;
        }
    }

    // Ako nijedan potez nije validan, ostaje na mestu
    cout << "Minotaur nije mogao da se pomeri.\n";
    return false;
}

void Lavirint::aktivirajPredmet() {
    srand(time(0));

    int randomPredmet = rand() % 4 + 1;

    if(randomPredmet == 1){
        cout << "Predmet: Magla rata\n";
        predmeti["Magla rata"] = 3;
    }
    else if (randomPredmet == 2) {
        cout << "Predmet: Mac\n";
        predmeti["Mac"] = 3;
    }
    else if (randomPredmet == 3) {
        cout << "Predmet: Stit\n";
        predmeti["Stit"] = 3;
    }
    else if (randomPredmet == 4) {
        cout << "Predmet: Cekic\n";
        predmeti["Cekic"] = 3;
    }
}